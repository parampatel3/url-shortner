# URL Shortener
A simple replit database based open source url-shorterner.
# Features
It's a simple-looking URL shortener based on replit DB. The key feature is if you made any short link with this script even if your replit project gets slept the link will still work.
## Necessary steps
Create a replit account from [here](https://replit.com/). Now fork this git from [here](https://repl.it/github/odd-coder/url-shortener).
## How to setup
1. Fork this project into your replit account.
2. Change the `DEFAULT_HOST` & `DEFAULT_BASE` to your repl url.
3. That's it run your repl.
## Fork
[Replit](https://repl.it/github/odd-coder/url-shortener).
## Support us
If you want you can join my discord server from [here](https://discord.gg/7KtdeePrHV).<br/>
Bytheway you can also star 🌟 this project if you want.
## Credit
Inspired from [bit.ly](htpps://bit.ly) :) & created by `Sestro#4472` with a cup of tea ☕❤
